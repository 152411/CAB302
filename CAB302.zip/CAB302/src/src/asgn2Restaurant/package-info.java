/**
 * This package contains classes that act as a bridge between the GUI, 
 * the log files and the classes in the asgn2Customers and the asgn2Pizzas packages. 
 *  
 * @author Person A and Person B
 *
 */
package asgn2Restaurant;