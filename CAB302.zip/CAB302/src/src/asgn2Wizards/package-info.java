/**
 * This package contains the entry point to the rest of the system
 *
 * @author PersonA and PersonB
 *
 */
package asgn2Wizards;